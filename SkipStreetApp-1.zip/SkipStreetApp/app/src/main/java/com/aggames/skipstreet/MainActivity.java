package com.aggames.skipstreet;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private AdView adView;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;

    // ============================================================
    // TEST AD UNIT IDs - Google's official public sandbox IDs.
    // These ALWAYS serve a placeholder "Test Ad" regardless of your
    // AdMob account's approval status, so you can confirm every ad
    // format works before your real ad units are approved.
    //
    // Swap each one back to your real AdMob ad unit ID before you
    // build the release you upload to Play Store.
    // ============================================================
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep the screen on while playing and go edge-to-edge.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemBars();

        // Start up the Mobile Ads SDK, then load every ad format so
        // they're ready by the time the game needs them.
        MobileAds.initialize(this, initializationStatus -> { });
        loadInterstitialAd();
        loadRewardedAd();

        // ---- Root layout: WebView (game) on top, banner ad pinned below ----
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);

        webView = new WebView(this);
        LinearLayout.LayoutParams webViewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        rootLayout.addView(webView, webViewParams);

        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(BANNER_AD_UNIT_ID);
        LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bannerParams.gravity = Gravity.CENTER_HORIZONTAL;
        rootLayout.addView(adView, bannerParams);

        setContentView(rootLayout);

        adView.loadAd(new AdRequest.Builder().build());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        // DOM storage (localStorage) is what the game already uses to save
        // the best score. Enabling it here means the save code in the game
        // works completely unchanged, and the score persists across app
        // restarts but is wiped automatically if the app is uninstalled -
        // exactly like normal Android app data.
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // Exposes window.AndroidAds.showInterstitial()/showRewarded() to
        // the game's JS.
        webView.addJavascriptInterface(new AndroidAdsBridge(), "AndroidAds");

        webView.loadUrl("file:///android_asset/index.html");
    }

    // ================================================================
    // INTERSTITIAL - full-screen ad shown after the player dies
    // (every 3-5 deaths, controlled from the game's JS).
    // ================================================================
    private void loadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, INTERSTITIAL_AD_UNIT_ID, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                interstitialAd = ad;
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                interstitialAd = null;
            }
        });
    }

    // ================================================================
    // REWARDED - "Watch Ad to Continue" button on the game-over screen.
    // Only grants the reward (a revive) if the user watches to the end.
    // ================================================================
    private void loadRewardedAd() {
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    /**
     * JS-callable bridge object. The game's JS calls
     * window.AndroidAds.showInterstitial() / showRewarded() when due.
     */
    private class AndroidAdsBridge {
        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    // Nothing loaded yet (e.g. no network right that
                    // moment) - don't block the player, just resume the
                    // game and try to have one ready for next time.
                    notifyGameAdClosed();
                    loadInterstitialAd();
                    return;
                }

                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        interstitialAd = null;
                        notifyGameAdClosed();
                        loadInterstitialAd(); // preload the next one
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError error) {
                        interstitialAd = null;
                        notifyGameAdClosed();
                        loadInterstitialAd();
                    }
                });

                interstitialAd.show(MainActivity.this);
            });
        }

        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    // Nothing loaded yet - tell the game so it doesn't sit
                    // waiting forever, and try to have one ready next time.
                    notifyRewardedAdClosed();
                    loadRewardedAd();
                    return;
                }

                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        notifyRewardedAdClosed();
                        loadRewardedAd(); // preload the next one
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError error) {
                        rewardedAd = null;
                        notifyRewardedAdClosed();
                        loadRewardedAd();
                    }
                });

                rewardedAd.show(MainActivity.this, rewardItem -> {
                    // User watched the whole ad and earned the reward -
                    // tell the game's JS to revive the player.
                    runOnUiThread(() -> webView.evaluateJavascript(
                            "window.__onRewardEarned && window.__onRewardEarned();", null));
                });
            });
        }
    }

    /** Tells the game's JS the interstitial has closed, so it can resume. */
    private void notifyGameAdClosed() {
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__onInterstitialClosed && window.__onInterstitialClosed();", null));
    }

    /** Tells the game's JS the rewarded ad has closed (earned or not). */
    private void notifyRewardedAdClosed() {
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__onRewardedAdClosed && window.__onRewardedAdClosed();", null));
    }

    private void hideSystemBars() {
        View decorView = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        // Let the WebView handle back navigation if it ever has history;
        // otherwise fall back to the default (exit) behavior.
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ---- Banner ad lifecycle: must mirror the Activity's lifecycle ----
    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }
}
